//
//  RestaurantCell.swift
//  LetsEat
//
//  Created by iOS 14 Programming on 16/07/2020.
//

import UIKit

class RestaurantCell: UICollectionViewCell {
    
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var lblCuisine: UILabel!
    
    @IBOutlet weak var imgRestaurant: UIImageView!
    
}
