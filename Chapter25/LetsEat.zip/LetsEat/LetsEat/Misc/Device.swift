//
//  Device.swift
//  LetsEat
//
//  Created by iOS 14 Programming on 30/07/2020.
//

import UIKit

struct Device {
    static var currentDevice:UIDevice {
        struct Singleton {
            static let device = UIDevice.current
        }
        return Singleton.device
    }
    
    static var isPhone: Bool {
        return currentDevice.userInterfaceIdiom == .phone
    }
    
    static var isPad: Bool {
        return currentDevice.userInterfaceIdiom == .pad 
    }
}
