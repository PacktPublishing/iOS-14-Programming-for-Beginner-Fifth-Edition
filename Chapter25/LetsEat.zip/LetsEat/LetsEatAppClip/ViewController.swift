//
//  ViewController.swift
//  LetsEatAppClip
//
//  Created by iOS 14 Programming on 14/08/2020.
//

import UIKit

class ViewController: UIViewController {
    
    fileprivate var items:[RestaurantItem] = []
    let manager = RestaurantDataManager()
    var selectedRestaurant:RestaurantItem?
    var selectedCity: String?
    var selectedRestaurantID: Int?
    var firstAppearance = true

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if firstAppearance {
            performSegue(withIdentifier: "showRestaurantDetail", sender: nil)
            firstAppearance = false
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let viewController = segue.destination as? RestaurantDetailViewController{
            if let city = selectedCity {
                manager.fetch(by: city, completionHandler:{
                    (items) in self.items = items
                })
            }
            if let id = selectedRestaurantID {
                for item in items {
                    if id == item.restaurantID {
                        selectedRestaurant = item
                    }
                }
            }
            viewController.selectedRestaurant = selectedRestaurant
        }
    }
}
