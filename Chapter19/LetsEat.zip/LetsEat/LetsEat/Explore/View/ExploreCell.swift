//
//  ExploreCell.swift
//  LetsEat
//
//  Created by iOS 14 Programming on 13/07/2020.
//

import UIKit

class ExploreCell: UICollectionViewCell {
    
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var imgExplore: UIImageView!
}
