//
//  ExploreHeaderView.swift
//  LetsEat
//
//  Created by iOS 14 Programming on 16/07/2020.
//

import UIKit

class ExploreHeaderView: UICollectionReusableView {
        
    @IBOutlet weak var lblLocation: UILabel!
}
