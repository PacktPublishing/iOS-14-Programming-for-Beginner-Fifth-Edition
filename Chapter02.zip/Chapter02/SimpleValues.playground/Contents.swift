import UIKit

var str = "Hello, playground"

let isRaining = true
isRaining = false

