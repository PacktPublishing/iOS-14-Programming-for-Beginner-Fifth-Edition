//
//  ContentView.swift
//  Shared
//
//  Created by iOS 14 Programming on 03/08/2020.
//

import SwiftUI

struct ContentView: View {
    var restaurantItems: [RestaurantItem] = []
    var body: some View {
        NavigationView{
            List(restaurantItems) { restaurantItem in
                RestaurantCell(restaurantItem: restaurantItem)
            }.navigationTitle("Boston,MA")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(restaurantItems: testData)
    }
}

struct RestaurantCell: View {
    
    var restaurantItem: RestaurantItem
    
    func getImage(imageURLString:String) -> UIImage {
        if let imageURL = URL(string: imageURLString), let data = try? Data(contentsOf: imageURL), let image = UIImage(data: data)  {
                return image
            }
        return UIImage(named: "nopic")!
    }
 
    
    
    var body: some View {
        NavigationLink(
            destination: RestaurantDetail(selectedRestaurant: restaurantItem)){
            Spacer()
            VStack {
                Text(restaurantItem.title)
                    .font(.headline)
                Text(restaurantItem.subtitle)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                Image(uiImage: getImage(imageURLString: restaurantItem.imageURL))
            }
            Spacer()
        }
    }
}
