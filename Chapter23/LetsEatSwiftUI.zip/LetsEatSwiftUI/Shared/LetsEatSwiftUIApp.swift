//
//  LetsEatSwiftUIApp.swift
//  Shared
//
//  Created by iOS 14 Programming on 03/08/2020.
//

import SwiftUI

@main
struct LetsEatSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
