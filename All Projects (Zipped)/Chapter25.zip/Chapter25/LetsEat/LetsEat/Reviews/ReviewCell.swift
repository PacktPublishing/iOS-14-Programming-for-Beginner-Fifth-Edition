//
//  ReviewCell.swift
//  LetsEat
//
//  Created by iOS 14 Programming on 17/10/2020.
//

import UIKit

class ReviewCell: UICollectionViewCell {
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblDate: UILabel!
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblReview: UILabel!
    @IBOutlet var ratingsView: RatingsView!
    
}
