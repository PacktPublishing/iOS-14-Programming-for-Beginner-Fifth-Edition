//
//  RestaurantCell.swift
//  LetsEat
//
//  Created by iOS 14 Programming on 14/10/2020.
//

import UIKit

class RestaurantCell: UICollectionViewCell {
    
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var lblCuisine: UILabel!
    
    @IBOutlet weak var ingRestaurant: UIImageView!
    
}
