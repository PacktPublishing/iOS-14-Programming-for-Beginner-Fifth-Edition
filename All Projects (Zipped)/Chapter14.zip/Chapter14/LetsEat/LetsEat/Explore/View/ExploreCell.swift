//
//  ExploreCell.swift
//  LetsEat
//
//  Created by iOS 14 Programming on 08/10/2020.
//

import UIKit

class ExploreCell: UICollectionViewCell {
    
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var imgExplore: UIImageView!
    
}
