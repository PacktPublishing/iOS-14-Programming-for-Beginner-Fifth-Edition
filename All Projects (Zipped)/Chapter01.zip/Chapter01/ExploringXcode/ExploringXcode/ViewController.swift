//
//  ViewController.swift
//  ExploringXcode
//
//  Created by iOS 14 Programming on 20/09/2020.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let a = 3
        // Do any additional setup after loading the view.
    }


}

